from django.db import models
from django.contrib.auth.models import User

class Racket(models.Model):
    name = models.CharField(max_length=100)
    brand = models.CharField(max_length=50)
    price = models.DecimalField(max_digits=8, decimal_places=2)
    description = models.TextField()
    stock = models.IntegerField()

    def __str__(self):
        return self.name

class Purchase(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    racket = models.ForeignKey(Racket, on_delete=models.CASCADE)
    date_purchased = models.DateTimeField(auto_now_add=True)
