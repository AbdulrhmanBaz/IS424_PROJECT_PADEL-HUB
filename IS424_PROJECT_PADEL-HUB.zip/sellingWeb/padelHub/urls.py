from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='login'), 
    path('register/', views.register_view, name='register'),  
    path('rackets/', views.rackets_list, name='rackets_list'),  
    path('rackets/add/', views.add_racket, name='add_racket'),  
    path('rackets/<int:racket_id>/update/', views.update_racket, name='update_racket'),  
    path('rackets/<int:racket_id>/', views.racket_detail, name='racket_detail'),  
    path('rackets/<int:racket_id>/purchase/', views.purchase_racket, name='purchase_racket'),
    path('logout/', views.logout_view, name='logout'),
]
