from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from .models import Racket

users = [{"username": "admin", "password": "admin123"}]
logged_in_user = None

def login_view(request):
    global logged_in_user
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        for user in users:
            if user["username"] == username and user["password"] == password:
                logged_in_user = username
                return redirect("rackets_list")
        return HttpResponse("Invalid username or password!")
    return render(request, "login.html")


def register_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        confirm_password = request.POST.get("confirm_password")
        if password != confirm_password:
            return HttpResponse("Passwords do not match!")
        if any(user["username"] == username for user in users):
            return HttpResponse("Username already exists!")
        users.append({"username": username, "password": password})
        return redirect("login")
    return render(request, "register.html")


def rackets_list(request):
    if not logged_in_user:
        return redirect("login")
    rackets = Racket.objects.all()
    return render(request, "rackets/list.html", {"rackets": rackets})


def add_racket(request):
    if request.method == "POST":
        Racket.objects.create(
            name=request.POST.get("name"),
            brand=request.POST.get("brand"),
            price=float(request.POST.get("price")),
            stock=int(request.POST.get("stock")),
            description=request.POST.get("description"),
        )
        return redirect("rackets_list")
    return render(request, "rackets/add.html")


def update_racket(request, racket_id):
    racket = get_object_or_404(Racket, id=racket_id)
    if request.method == "POST":
        racket.name = request.POST.get("name")
        racket.brand = request.POST.get("brand")
        racket.price = float(request.POST.get("price"))
        racket.stock = int(request.POST.get("stock"))
        racket.description = request.POST.get("description")
        racket.save()
        return redirect("rackets_list")
    return render(request, "rackets/update.html", {"racket": racket})


def racket_detail(request, racket_id):
    racket = get_object_or_404(Racket, id=racket_id)
    return render(request, "rackets/detail.html", {"racket": racket})


def purchase_racket(request, racket_id):
    racket = get_object_or_404(Racket, id=racket_id)
    if request.method == "POST":
        if racket.stock > 0:
            racket.stock -= 1
            racket.save()
            context = {"success": True, "message": f"Successfully purchased {racket.name}!"}
        else:
            context = {"success": False, "message": f"Sorry, {racket.name} is out of stock!"}
        return render(request, "rackets/purchase_result.html", context)
    return redirect("rackets_list")


def logout_view(request):
    global logged_in_user
    logged_in_user = None
    return redirect("login")
